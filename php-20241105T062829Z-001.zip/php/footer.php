<footer>
    <p>&copy; 2024 Lia's Pet Shop. All rights reserved.</p>
</footer>
