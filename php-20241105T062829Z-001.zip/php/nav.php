<nav>
    <h1>Lia's Pet Shop</h1>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="product.php">Shop</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
</nav>
